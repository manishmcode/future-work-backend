export interface Subscription {
    id: number;
    user_id: number;
    plan_name: string;
    price: string | number;
    status: string;
    payment_status: string;
    payment_reference: string;
    starts_at: Date;
    ends_at: Date | null;
    cancelled_at: Date | null;
    created_at: Date;
    updated_at: Date;
}

export interface CreateMockSubscriptionPayload {
    plan_name: string;
    price: number;
}

export interface UnsubscribePayload {
    first_name: string;
    last_name: string;
    email: string;
    iban_last_5: string;
    message?: string | undefined;
    is_unsubscribe?: boolean | undefined;
    options?: unknown | undefined;
}

export interface UnsubscribeResponse {
    email: string;
    cancelled_count: number;
    status: string;
}

export interface SubscriptionResponse {
    id: number;
    user_id: number;
    plan_name: string;
    price: number;
    status: string;
    payment_status: string;
    payment_reference: string;
    starts_at: Date;
    ends_at: Date | null;
    cancelled_at: Date | null;
    created_at: Date;
    updated_at: Date;
}
