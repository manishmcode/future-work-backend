import { AppError } from "../../common/errors/app-error";
import { findUserByEmail } from "../user/user.repository";
import {
    cancelActiveSubscriptionsByUserId,
    createSubscription,
    getLatestSubscriptionByUserId,
    listSubscriptionsByUserId,
} from "./subscription.repository";
import { insertContactUs } from "./contact.repository";
import {
    CreateMockSubscriptionPayload,
    Subscription,
    SubscriptionResponse,
    UnsubscribePayload,
    UnsubscribeResponse,
} from "./subscription.types";

function mapSubscriptionRow(row: Subscription): SubscriptionResponse {
    return {
        ...row,
        price: Number(row.price),
    };
}

export async function createMockSubscription(
    userId: number,
    payload: CreateMockSubscriptionPayload,
): Promise<SubscriptionResponse> {
    const paymentReference = `${Date.now()}_${userId}`;
    const startsAt = new Date();
    const endsAt = new Date(startsAt);
    endsAt.setMonth(endsAt.getMonth() + 1);

    const created = await createSubscription({
        user_id: userId,
        plan_name: payload.plan_name,
        price: payload.price,
        status: "active",
        payment_status: "success",
        payment_reference: paymentReference,
        starts_at: startsAt,
        ends_at: endsAt,
    });

    return mapSubscriptionRow(created);
}

export async function getMyCurrentPlan(userId: number): Promise<SubscriptionResponse> {
    const subscription = await getLatestSubscriptionByUserId(userId);

    if (!subscription) {
        throw new AppError("No subscription found for this user", 404);
    }

    return mapSubscriptionRow(subscription);
}

export async function getMySubscriptionHistory(userId: number): Promise<SubscriptionResponse[]> {
    const rows = await listSubscriptionsByUserId(userId);
    return rows.map(mapSubscriptionRow);
}

export async function unsubscribePlan(payload: UnsubscribePayload): Promise<UnsubscribeResponse> {
    const user = await findUserByEmail(payload.email);

    if (!user) {
        throw new AppError("Email does not exist", 404);
    }

    // Merge frontend-provided options with metadata
    const mergedOptions = {
        ...(payload.options ?? {}),
        first_name: payload.first_name,
        last_name: payload.last_name,
        is_unsubscribe: payload.is_unsubscribe ?? true,
        iban_last_5: payload.iban_last_5,
    };

    await insertContactUs({
        email: payload.email,
        message: payload.message ?? null,
        options: mergedOptions,
    });

    const shouldUnsubscribe = payload.is_unsubscribe === undefined ? true : Boolean(payload.is_unsubscribe);

    if (!shouldUnsubscribe) {
        return {
            email: payload.email,
            cancelled_count: 0,
            status: "contact_saved",
        };
    }

    const cancelledCount = await cancelActiveSubscriptionsByUserId(user.id);

    if (!cancelledCount) {
        throw new AppError("No active subscription found for this user", 404);
    }

    return {
        email: payload.email,
        cancelled_count: cancelledCount,
        status: "cancelled",
    };
}
