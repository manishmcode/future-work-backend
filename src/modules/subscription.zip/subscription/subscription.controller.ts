import { NextFunction, Request, Response } from "express";
import { AppError } from "../../common/errors/app-error";
import { AuthRequest } from "../../common/middlewares/auth.middleware";
import { sendSuccess } from "../../common/utils/api-response";
import { createMockSubscriptionSchema, unsubscribeSchema } from "./subscription.schemas";
import {
    createMockSubscription,
    getMyCurrentPlan,
    getMySubscriptionHistory,
    unsubscribePlan,
} from "./subscription.service";

export async function createMockSubscriptionController(
    req: AuthRequest,
    res: Response,
    next: NextFunction,
): Promise<void> {
    try {
        const userId = req.authUser?.userId;

        if (!userId) {
            throw new AppError("Unauthorized", 401);
        }

        const parsed = createMockSubscriptionSchema.safeParse(req.body);

        if (!parsed.success) {
            throw new AppError(parsed.error.issues.map((issue) => issue.message).join(", "), 422);
        }

        const result = await createMockSubscription(userId, parsed.data);
        sendSuccess(res, "Mock subscription created successfully", result, 201);
    } catch (error) {
        next(error);
    }
}

export async function getMyCurrentPlanController(
    req: AuthRequest,
    res: Response,
    next: NextFunction,
): Promise<void> {
    try {
        const userId = req.authUser?.userId;

        if (!userId) {
            throw new AppError("Unauthorized", 401);
        }

        const result = await getMyCurrentPlan(userId);
        sendSuccess(res, "Current plan fetched successfully", result);
    } catch (error) {
        next(error);
    }
}

export async function getMySubscriptionHistoryController(
    req: AuthRequest,
    res: Response,
    next: NextFunction,
): Promise<void> {
    try {
        const userId = req.authUser?.userId;

        if (!userId) {
            throw new AppError("Unauthorized", 401);
        }

        const result = await getMySubscriptionHistory(userId);
        sendSuccess(res, "Subscription history fetched successfully", result);
    } catch (error) {
        next(error);
    }
}

export async function unsubscribeController(
    req: Request,
    res: Response,
    next: NextFunction,
): Promise<void> {
    try {
        const parsed = unsubscribeSchema.safeParse(req.body);

        if (!parsed.success) {
            throw new AppError(parsed.error.issues.map((issue) => issue.message).join(", "), 422);
        }

        const result = await unsubscribePlan(parsed.data as any);
        const msg = result.status === "contact_saved" ? "Contact request saved" : "Subscription cancelled successfully";
        sendSuccess(res, msg, result);
    } catch (error) {
        next(error);
    }
}
