import { db } from "../../config/db";
import { Subscription } from "./subscription.types";

const SUBSCRIPTIONS_TABLE = "subscriptions";

export async function createSubscription(data: {
    user_id: number;
    plan_name: string;
    price: number;
    status: string;
    payment_status: string;
    payment_reference: string;
    starts_at: Date;
    ends_at: Date;
}): Promise<Subscription> {
    const [created] = await db<Subscription>(SUBSCRIPTIONS_TABLE)
        .insert(data)
        .returning("*");

    return created as Subscription;
}

export async function getLatestSubscriptionByUserId(userId: number): Promise<Subscription | undefined> {
    return db<Subscription>(SUBSCRIPTIONS_TABLE)
        .where({ user_id: userId })
        .orderBy("created_at", "desc")
        .first();
}

export async function listSubscriptionsByUserId(userId: number): Promise<Subscription[]> {
    return db<Subscription>(SUBSCRIPTIONS_TABLE)
        .where({ user_id: userId })
        .orderBy("created_at", "desc");
}

export async function cancelActiveSubscriptionsByUserId(userId: number): Promise<number> {
    const now = new Date();

    const updatedRows = await db<Subscription>(SUBSCRIPTIONS_TABLE)
        .where({ user_id: userId, status: "active" })
        .update({
            status: "cancelled",
            payment_status: "cancelled",
            cancelled_at: now,
            ends_at: now,
            updated_at: now,
        })
        .returning("id");

    return updatedRows.length;
}
