import { z } from "zod";

export const createMockSubscriptionSchema = z.object({
    plan_name: z.string().min(2, "plan_name must be at least 2 characters"),
    price: z.number().positive("price must be greater than 0"),
});

export const unsubscribeSchema = z.object({
    first_name: z.string().min(2, "first_name must be at least 2 characters").optional(),
    last_name: z.string().min(2, "last_name must be at least 2 characters").optional(),
    email: z.email("Provide a valid email"),
    iban_last_5: z.string().regex(/^\d{5}$/, "iban_last_5 must be exactly 5 digits").optional(),
    message: z.string().optional(),
    is_unsubscribe: z.boolean().optional().default(true),
    // Accept any shape for `options` from frontend to avoid parse errors (object or array)
    options: z.any().optional(),
});
