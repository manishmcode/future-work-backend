import { Router } from "express";
import { authMiddleware } from "../../common/middlewares/auth.middleware";
import {
    createMockSubscriptionController,
    getMyCurrentPlanController,
    getMySubscriptionHistoryController,
    unsubscribeController,
} from "./subscription.controller";

const subscriptionRouter = Router();

subscriptionRouter.post("/unsubscribe", unsubscribeController);
subscriptionRouter.use(authMiddleware);
subscriptionRouter.post("/purchase", createMockSubscriptionController);
subscriptionRouter.get("/my-plan", getMyCurrentPlanController);
subscriptionRouter.get("/history", getMySubscriptionHistoryController);

export { subscriptionRouter };
